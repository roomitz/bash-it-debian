# shellcheck shell=bash
about-alias 'Aliases for Terraform and Terragrunt'

alias tf='terraform'
alias tfv='terraform validate'
alias tfp='terraform plan'
alias tfa='terraform apply'
alias tfd='terraform destroy'
