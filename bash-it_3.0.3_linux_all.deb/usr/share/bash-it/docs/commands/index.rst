.. _commands:

Bash-it Commands
================

**Bash-it** boasts a wide range of available commands.
You should be familiar with them in order to fully utilize Bash-it.

.. toctree::
   :maxdepth: 1

   update
   search
   reload
   doctor
   profile
