_command_exists minishift && source <(minishift completion bash)
