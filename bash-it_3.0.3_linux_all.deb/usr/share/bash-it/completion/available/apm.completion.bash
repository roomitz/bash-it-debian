# shellcheck shell=bash
about-completion "apm completion"
# shellcheck disable=SC1090
source "${BASH_IT}"/vendor/github.com/vigo/apm-bash-completion/apm
