.. _oh-my-posh:

Oh-My-Posh Theme
================

The oh-my-posh ״theme״ is really a plug to a whole other system
of managing your prompt. To use it please start here:
`Oh-My-Posh homepage <https://ohmyposh.dev/>`_

It is beyond the scope of bash-it to install and manage oh-my-posh,
this theme is here just to make sure your OMP setup doesn't clash
with other bash-it themes. Once installed, OMP will load a default
OMP theme (jandedobbeleer), which you can then customize or override.

Note: Nerd Fonts are highly recommended, as most of the themes are graphic candies.
