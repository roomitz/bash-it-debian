_log_warning 'Bash completion for "homesick" is now deprecated, as it used unlicensed code.
Please disable this completion and use the instructions from "homesick" bash completion developers instead.'
