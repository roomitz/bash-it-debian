# shellcheck shell=bash
_log_warning '"docker-machine" is now deprecated, and as such the bash completion for it is also deprecated.
Please disable this completion.'
