# shellcheck shell=bash
about-completion "django completion"
# shellcheck disable=SC1090
source "${BASH_IT}"/vendor/github.com/django/django/extras/django_bash_completion
