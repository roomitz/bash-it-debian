# shellcheck shell=bash

if _command_exists pew
then
	source "$(pew shell_config)"
fi
