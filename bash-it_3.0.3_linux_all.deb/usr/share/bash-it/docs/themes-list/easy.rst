.. _easy:

Easy Theme
==========

A simple theme

Examples
--------

.. code-block:: bash

    user@hostname ~/.bash_it
    [ master ✓ ] ❯
